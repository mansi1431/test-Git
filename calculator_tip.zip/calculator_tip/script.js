//creating custom function
function calculateTip(){
    //store input values in variables
    var billAmt = document.getElementById("billAmt").value;
    console.log(billAmt);
    var serviceQty = document.getElementById("serviceQty").value;
    console.log(serviceQty);
    var numpeople = document.getElementById("numpeople").value;
    console.log(numpeople);
    //validations
    if(billAmt === "" || serviceQty === 0){
        window.alert("Please enter values");
        return; // stops funtion from continuing
    }
    //when the value of numpeople is less than or equal to 1
    if(numpeople === "" || numpeople<=1){
        numpeople = 1;

        document.getElementById("each").style.display="none";
    }
    else{
        document.getElementById("each").style.display="block";
    }
    //Calculation
    var total = (billAmt * serviceQty) / numpeople;
    total = Math.round(total * 100) / 100;
    total = total.toFixed(2);

    //Display tip
    document.getElementById("totaltip").style.display = "block";
    document.getElementById("tip").innerHTML = total;
}


//Hide tip amount and each on load
document.getElementById("totaltip").style.display = "none";
document.getElementById("each").style.display = "none";

//calling the custom function
document.getElementById("calculate").onclick = function(){ calculateTip(); };