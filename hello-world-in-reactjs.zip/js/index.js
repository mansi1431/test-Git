ReactDOM.render(React.createElement("h1", null, "HELLO REACT"), document.getElementById('hello'));

ReactDOM.render(React.createElement("h1", null, "HELLO REACT"), document.getElementById('world'));